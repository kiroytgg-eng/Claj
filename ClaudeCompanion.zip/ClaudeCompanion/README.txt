CLAUDE COMPANION - Forge 1.20.1

1) Baja el MDK oficial de Forge 1.20.1 (47.x) desde files.minecraftforge.net.
2) Borra el src/ del MDK y copia este src/ en su lugar.
3) En gradle.properties del MDK pon: mod_id=claudecompanion, mod_name=Claude Companion
   (y borra el mods.toml / clase de ejemplo si el MDK trae otros).
4) Ejecuta: gradlew build   -> el .jar queda en build/libs/
5) Mete el .jar en la carpeta mods/, abre el juego una vez y cierra.
6) Edita config/claudecompanion-common.toml y pega tu apiKey de Anthropic.
7) En el juego: /claude <mensaje>  o escribe en el chat: @claude <mensaje>
   /claude reset  -> borra la memoria de la conversación.

CUERPO DE JUGADOR
 /claude spawn     -> aparece Claude con cuerpo de jugador: te sigue, pelea contra monstruos.
 /claude despawn   -> lo quita.
 Clic derecho con espada/hacha/armadura -> se la equipa.
 Su skin esta en src/main/resources/assets/claudecompanion/textures/entity/claude.png (64x64, cambiala por la que quieras).

HABLAR COMO AMIGO
 Con /claude spawn, Claude responde a todo lo que escribas en el chat.
 Sin su cuerpo, responde cuando tu mensaje contiene "claude" (ej: "claude dame comida").
 Config: respondToAllWhenSpawned=false para que solo responda cuando lo nombres.
