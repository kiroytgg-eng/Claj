package com.claudecompanion;

import com.google.gson.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.regex.*;

public class ClaudeCommand {
    private static final Map<UUID, JsonArray> HISTORY = new HashMap<>();
    private static final Pattern GIVE = Pattern.compile("\\[\\[GIVE\\s+([a-z0-9_.-]+:[a-z0-9_/.-]+)\\s+(\\d+)\\]\\]");

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("claude")
                .then(Commands.literal("spawn").executes(c -> {
                    spawn(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("despawn").executes(c -> {
                    removeBodies(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reset").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    HISTORY.remove(p.getUUID());
                    p.sendSystemMessage(Component.literal("§d<Claude>§r Memoria de la conversación borrada."));
                    return 1;
                }))
                .then(Commands.argument("mensaje", StringArgumentType.greedyString()).executes(c -> {
                    ask(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "mensaje"));
                    return 1;
                })));
    }

    public static boolean hasBody(ServerPlayer p) {
        return !p.serverLevel().getEntities(EntityTypeTest.forClass(ClaudeEntity.class),
                x -> p.getUUID().equals(x.getOwnerId())).isEmpty();
    }

    private static void removeBodies(ServerPlayer p) {
        for (ClaudeEntity e : p.serverLevel().getEntities(EntityTypeTest.forClass(ClaudeEntity.class),
                x -> p.getUUID().equals(x.getOwnerId()))) {
            e.discard();
        }
    }

    private static void spawn(ServerPlayer p) {
        removeBodies(p);
        ServerLevel lvl = p.serverLevel();
        ClaudeEntity e = ModEntities.CLAUDE.get().create(lvl);
        if (e == null) return;
        e.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0.0F);
        e.setOwner(p);
        e.setCustomName(Component.literal("Claude"));
        e.setCustomNameVisible(true);
        e.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
        lvl.addFreshEntity(e);
        p.sendSystemMessage(Component.literal("§d<Claude>§r ¡Ya estoy aquí contigo!"));
    }

    private static String systemPrompt(String playerName) {
        String give = Config.ALLOW_GIVE.get()
                ? "Si el jugador te pide objetos, o ves que le harian falta para avanzar, puedes dárselos escribiendo AL FINAL de tu respuesta, una por línea, "
                + "la etiqueta exacta [[GIVE id_del_objeto cantidad]], por ejemplo [[GIVE minecraft:iron_sword 1]]. Usa solo ids válidos de Minecraft 1.20.1."
                : "No puedes dar objetos; solo aconseja.";
        return "Eres Claude, el mejor amigo del jugador " + playerName + ", y vives dentro de Minecraft Java 1.20.1 (Forge) con un cuerpo de jugador que lo sigue a todas partes. "
                + "Habla como un amigo real: natural, cercano, con humor, en español, en 1 a 3 frases cortas, sin markdown ni listas. "
                + "Charla de lo que sea y también ayúdalo a pasarse el juego (llegar al End y vencer al Ender Dragon), diciéndole qué hacer según su estado, su inventario y lo que hay cerca. "
                + "Recibes el estado del jugador antes de cada mensaje; úsalo pero no lo recites. " + give;
    }

    private static String context(ServerPlayer p) {
        Map<String, Integer> inv = new TreeMap<>();
        List<ItemStack> all = new ArrayList<>();
        all.addAll(p.getInventory().items);
        all.addAll(p.getInventory().armor);
        all.addAll(p.getInventory().offhand);
        for (ItemStack s : all) {
            if (s.isEmpty()) continue;
            ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
            inv.merge(k == null ? "?" : k.toString(), s.getCount(), Integer::sum);
        }
        Map<String, Integer> near = new TreeMap<>();
        for (LivingEntity x : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(16), y -> y != p)) {
            ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(x.getType());
            near.merge(k == null ? "?" : k.getPath(), 1, Integer::sum);
        }
        String biome = p.level().getBiome(p.blockPosition()).unwrapKey().map(k -> k.location().toString()).orElse("?");
        return "[Estado: dimensión=" + p.level().dimension().location()
                + ", bioma=" + biome
                + ", pos=" + p.blockPosition().toShortString()
                + ", vida=" + (int) p.getHealth() + "/" + (int) p.getMaxHealth()
                + ", hambre=" + p.getFoodData().getFoodLevel()
                + ", hora=" + (p.level().getDayTime() % 24000)
                + ", inventario=" + inv + ", cerca(16 bloques)=" + near + "]";
    }

    public static void ask(ServerPlayer player, String text) {
        JsonArray hist = HISTORY.computeIfAbsent(player.getUUID(), k -> new JsonArray());
        while (hist.size() >= 12) hist.remove(0);
        while (hist.size() > 0 && !"user".equals(hist.get(0).getAsJsonObject().get("role").getAsString())) hist.remove(0);

        JsonObject um = new JsonObject();
        um.addProperty("role", "user");
        um.addProperty("content", context(player) + "\n" + text);
        hist.add(um);

        JsonArray snapshot = hist.deepCopy();
        String system = systemPrompt(player.getName().getString());
        var server = player.getServer();
        player.displayClientMessage(Component.literal("§7Claude está pensando..."), true);

        CompletableFuture.runAsync(() -> {
            try {
                String reply = ClaudeClient.ask(system, snapshot);
                server.execute(() -> deliver(player, reply));
            } catch (Exception ex) {
                server.execute(() -> {
                    JsonArray h = HISTORY.get(player.getUUID());
                    if (h != null && h.size() > 0) h.remove(h.size() - 1);
                    player.sendSystemMessage(Component.literal("§c<Claude> Error: " + ex.getMessage()));
                });
            }
        });
    }

    private static void deliver(ServerPlayer player, String reply) {
        JsonArray hist = HISTORY.computeIfAbsent(player.getUUID(), k -> new JsonArray());
        JsonObject am = new JsonObject();
        am.addProperty("role", "assistant");
        am.addProperty("content", reply);
        hist.add(am);

        Matcher m = GIVE.matcher(reply);
        List<String> given = new ArrayList<>();
        while (m.find() && Config.ALLOW_GIVE.get()) {
            ResourceLocation rl = ResourceLocation.tryParse(m.group(1));
            if (rl == null || !ForgeRegistries.ITEMS.containsKey(rl)) continue;
            Item item = ForgeRegistries.ITEMS.getValue(rl);
            int left = Math.min(Integer.parseInt(m.group(2)), Config.MAX_PER_GIVE.get());
            int total = left;
            while (left > 0) {
                int n = Math.min(left, item.getMaxStackSize());
                ItemStack st = new ItemStack(item, n);
                if (!player.getInventory().add(st)) player.drop(st, false);
                left -= n;
            }
            given.add(total + "x " + rl);
        }

        for (ClaudeEntity body : player.serverLevel().getEntities(EntityTypeTest.forClass(ClaudeEntity.class),
                x -> player.getUUID().equals(x.getOwnerId()))) {
            body.swing(InteractionHand.MAIN_HAND);
        }

        String clean = GIVE.matcher(reply).replaceAll("").trim();
        player.sendSystemMessage(Component.literal("§d<Claude>§r " + clean));
        if (!given.isEmpty()) {
            player.sendSystemMessage(Component.literal("§a<Claude> te dio: " + String.join(", ", given)));
        }
    }
}
