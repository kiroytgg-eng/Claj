package com.claudecompanion;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public class ClaudeClient {
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static String ask(String system, JsonArray messages) throws Exception {
        String key = Config.API_KEY.get();
        if (key == null || key.isBlank()) {
            throw new IllegalStateException("Falta la apiKey en config/claudecompanion-common.toml");
        }
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.MODEL.get());
        body.addProperty("max_tokens", 700);
        body.addProperty("system", system);
        body.add("messages", messages);

        HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                .header("content-type", "application/json")
                .header("x-api-key", key)
                .header("anthropic-version", "2023-06-01")
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) {
            throw new RuntimeException("HTTP " + res.statusCode() + ": " + res.body());
        }
        JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : json.getAsJsonArray("content")) {
            JsonObject o = e.getAsJsonObject();
            if ("text".equals(o.get("type").getAsString())) sb.append(o.get("text").getAsString());
        }
        return sb.toString();
    }
}
