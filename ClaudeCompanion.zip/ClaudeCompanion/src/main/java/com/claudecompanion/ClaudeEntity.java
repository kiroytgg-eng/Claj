package com.claudecompanion;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;

import java.util.EnumSet;
import java.util.UUID;

/** El cuerpo de jugador de Claude: te sigue, pelea contra monstruos y puedes equiparlo con clic derecho. */
public class ClaudeEntity extends PathfinderMob {
    private UUID ownerId;

    public ClaudeEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    public void setOwner(Player p) { this.ownerId = p.getUUID(); }

    public UUID getOwnerId() { return ownerId; }

    Player getOwner() {
        return ownerId == null ? null : this.level().getPlayerByUUID(ownerId);
    }

    @Override
    public boolean removeWhenFarAway(double d) { return false; }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.isEmpty()) return InteractionResult.PASS;
        EquipmentSlot slot = Mob.getEquipmentSlotForItem(held);
        if (slot == EquipmentSlot.MAINHAND && !(held.getItem() instanceof SwordItem || held.getItem() instanceof AxeItem)) {
            return InteractionResult.PASS;
        }
        if (!this.level().isClientSide) {
            ItemStack old = this.getItemBySlot(slot);
            if (!old.isEmpty()) this.spawnAtLocation(old);
            this.setItemSlot(slot, held.split(1));
            this.setDropChance(slot, 1.0F);
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerId != null) tag.putUUID("Owner", ownerId);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) ownerId = tag.getUUID("Owner");
    }

    static class FollowOwnerGoal extends Goal {
        private final ClaudeEntity mob;
        private int recalc;

        FollowOwnerGoal(ClaudeEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = mob.getOwner();
            return o != null && !o.isSpectator() && mob.distanceToSqr(o) > 36.0D;
        }

        @Override
        public boolean canContinueToUse() {
            Player o = mob.getOwner();
            return o != null && mob.distanceToSqr(o) > 9.0D;
        }

        @Override
        public void tick() {
            Player o = mob.getOwner();
            if (o == null) return;
            mob.getLookControl().setLookAt(o, 10.0F, mob.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (mob.distanceToSqr(o) > 576.0D) {
                    mob.teleportTo(o.getX(), o.getY(), o.getZ());
                    mob.getNavigation().stop();
                } else {
                    mob.getNavigation().moveTo(o, 1.2D);
                }
            }
        }

        @Override
        public void stop() { mob.getNavigation().stop(); }
    }
}
