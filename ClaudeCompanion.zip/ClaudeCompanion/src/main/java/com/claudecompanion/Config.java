package com.claudecompanion;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.BooleanValue ALLOW_GIVE;
    public static final ForgeConfigSpec.BooleanValue RESPOND_ALL;
    public static final ForgeConfigSpec.IntValue MAX_PER_GIVE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        API_KEY = b.comment("Tu API key de Anthropic (console.anthropic.com)").define("apiKey", "");
        MODEL = b.comment("Modelo de Claude a usar").define("model", "claude-sonnet-5-5");
        ALLOW_GIVE = b.comment("Permitir que Claude te dé objetos").define("allowGive", true);
        RESPOND_ALL = b.comment("Si el cuerpo de Claude esta invocado (/claude spawn), responde a TODO lo que escribas en el chat. Si es false, solo cuando digas 'claude'").define("respondToAllWhenSpawned", true);
        MAX_PER_GIVE = b.comment("Máximo de unidades por objeto en cada entrega").defineInRange("maxPerGive", 64, 1, 2304);
        SPEC = b.build();
    }
}
